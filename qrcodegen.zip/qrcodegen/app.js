let submitBtn = document.getElementById("btn");
let qrImage = document.querySelector(".qrimage");
let Value = document.getElementById("inputgenerator");
let imageShown = document.getElementById("imagedata");


submitBtn.addEventListener("click",(e)=>{
    e.preventDefault();
    
    let inputValue = Value.value;
    let pattern = /((?:(?:http?|ftp)[s]*:\/\/)?[a-z0-9-%\/\&=?\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?)/gi
    let x = pattern.test(inputValue)
    if(x){
        let apiCode = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${inputValue}`
        imageShown.src = apiCode;
        console.log(imageShown.src)
        qrImage.classList.add("active")
    }
    else{
        alert("false")
    }
    console.log(x)
})

Value.addEventListener("keyup",()=>{
    qrImage.classList.remove("active")

})